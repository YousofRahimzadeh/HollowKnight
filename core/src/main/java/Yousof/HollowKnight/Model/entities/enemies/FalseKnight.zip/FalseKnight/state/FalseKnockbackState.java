package Yousof.HollowKnight.Model.entities.enemies.FalseKnight.state;

import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Body;

import Yousof.HollowKnight.Enum.Constants;
import Yousof.HollowKnight.Model.entities.enemies.FalseKnight.FalseKnightEnemy;

public class FalseKnockbackState extends FalseKnightState {

    private FalseKnightState stateWrapper;
    private float duration = 0.3f;
    private float timer = 0f;
    private Body attackerBody;
    private float strength;

    public FalseKnockbackState(Body attackerBody, FalseKnightState lastState, float strength) {
        this.attackerBody = attackerBody;
        this.strength = strength;

        if (lastState instanceof FalseKnockbackState) {
            FalseKnockbackState lastKnock = (FalseKnockbackState) lastState;
            this.stateWrapper = lastKnock.stateWrapper;

            // fixed: pull timing/animation from the wrapped visual state,
            // not from the outer knockback's own bookkeeping fields
            FalseKnightState visualState = (lastKnock.stateWrapper != null) ? lastKnock.stateWrapper : lastState;
            this.stateTime = visualState.stateTime;
            this.currentAnimation = visualState.currentAnimation;
        } else {
            this.stateWrapper = lastState;
            this.stateTime = lastState.stateTime;
            this.currentAnimation = lastState.currentAnimation;
        }
    }

    @Override
    public void enter(FalseKnightEnemy enemy) {
        super.enter(enemy);
        enemy.setOnKnock(true);
        this.timer = 0f;

        if (body != null && attackerBody != null) {
            Vector2 enemyPos = body.getPosition();
            Vector2 attackerPos = attackerBody.getPosition();

            float dirX = (enemyPos.x - attackerPos.x) > 0 ? 1f : -1f;

            body.setLinearVelocity(0, body.getLinearVelocity().y);

            body.applyLinearImpulse(
                new Vector2(dirX * strength, strength * 2f),
                body.getWorldCenter(),
                true
            );
        }
    }

    @Override
    public void update(float delta) {
        super.update(delta); // fixed: was manually duplicating stateTime += delta only
        stateWrapper.update(delta);
        timer += delta;
        if (timer >= duration) {
            enemy.setOnKnock(false);
            if (stateWrapper != null) {
                enemy.changeState(stateWrapper);
            } else {
                enemy.changeState(new FalseIdleState());
            }
        }
    }

    @Override
    public void draw(Batch batch) {
        TextureRegion currentFrame = currentAnimation.getKeyFrame(stateTime);
        if (enemy.isFacingRight() && !currentFrame.isFlipX()) {
            currentFrame.flip(true, false);
        } else if (!enemy.isFacingRight() && currentFrame.isFlipX()) {
            currentFrame.flip(true, false);
        }

        float drawX = body.getPosition().x * Constants.PPM - (currentFrame.getRegionWidth() / 2f);
        float drawY = body.getPosition().y * Constants.PPM - (currentFrame.getRegionHeight() / 2f) + 130f;

        float oldColor = batch.getPackedColor();
        batch.setColor(batch.getColor().r, batch.getColor().g, batch.getColor().b, 0.6f);
        batch.draw(currentFrame, drawX, drawY);
        batch.setPackedColor(oldColor);
    }

    @Override
    public void exit() {
        if (body != null) {
            body.setLinearVelocity(0, body.getLinearVelocity().y);
        }
    }

    public void changeState(FalseKnightState newState) {
        if (newState instanceof FalseDeathState || newState instanceof FalseStunState) {
            enemy.setOnKnock(false);
            if (stateWrapper != null) stateWrapper.exit();
            enemy.changeState(newState);
            return;
        }
        if (!(newState instanceof FalseKnockbackState)) {
            this.stateWrapper = newState;
        }
    }
}